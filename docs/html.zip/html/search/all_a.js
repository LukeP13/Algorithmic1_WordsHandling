var searchData=
[
  ['paraules',['paraules',['../class_song.html#a8e70c20ee5d776e6d174240995b067d7',1,'Song']]]
];
