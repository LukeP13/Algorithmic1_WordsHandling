var searchData=
[
  ['deleteid',['deleteId',['../main_8cpp.html#a3e141ccc5d02fb279618392149e032a6',1,'main.cpp']]],
  ['deletesong',['deleteSong',['../class_songs.html#ab4e301c515d165edfc78ee79b965558f',1,'Songs']]]
];
