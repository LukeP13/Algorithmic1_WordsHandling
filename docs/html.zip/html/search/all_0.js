var searchData=
[
  ['addsong',['addSong',['../class_songs.html#a6799ddad7af7b27b366b6b43b343dae3',1,'Songs']]],
  ['addword',['addWord',['../class_song.html#acd87e76192df5408435cc4dfeb785397',1,'Song::addWord()'],['../class_songs.html#a7883193508bde2f67d2b87b062964bc7',1,'Songs::addWord()']]]
];
