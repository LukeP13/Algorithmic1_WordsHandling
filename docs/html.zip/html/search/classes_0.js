var searchData=
[
  ['myexception',['myexception',['../classmyexception.html',1,'']]]
];
