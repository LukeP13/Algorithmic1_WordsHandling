var searchData=
[
  ['tid',['tid',['../class_song.html#a5c888b5f5afff211fb0c4818f99f3ddb',1,'Song']]],
  ['tractarop',['tractarOp',['../main_8cpp.html#a0081290c0d81a2119bca5ae4c0ff2426',1,'main.cpp']]]
];
