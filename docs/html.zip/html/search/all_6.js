var searchData=
[
  ['ignorarcomentaris',['ignorarComentaris',['../main_8cpp.html#a80b5222678194224cb7d46f0ca33bb61',1,'main.cpp']]]
];
