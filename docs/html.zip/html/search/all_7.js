var searchData=
[
  ['llegirmfw',['llegirMFW',['../main_8cpp.html#a88f6df82d3f3f97f80c3d2f93ad49030',1,'main.cpp']]],
  ['llegirmsd',['llegirMSD',['../main_8cpp.html#a00c5a4994344cccb03bd69186fd02c2a',1,'main.cpp']]],
  ['llegirmxm',['llegirMXM',['../main_8cpp.html#ac98514d551a9f410c9410027115d40ca',1,'main.cpp']]],
  ['llegwordsong',['llegWordSong',['../main_8cpp.html#a7dc0fdcf32d93f2810175aeed9b001a3',1,'main.cpp']]]
];
