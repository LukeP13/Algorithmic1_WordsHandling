var searchData=
[
  ['operacions',['Operacions',['../main_8cpp.html#aeb00393230810abb86495afef8a1c5d5',1,'main.cpp']]]
];
