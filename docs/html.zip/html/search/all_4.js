var searchData=
[
  ['getid',['getId',['../main_8cpp.html#a47d259dd8eaf247ba8f0ab688435bb20',1,'main.cpp']]],
  ['getinfo',['getInfo',['../class_song.html#aee7b19626c5cea2322e050afb124f1c9',1,'Song']]],
  ['getsong',['getSong',['../class_songs.html#a01879ad0a21ed5ddb18ea8807a998201',1,'Songs']]]
];
