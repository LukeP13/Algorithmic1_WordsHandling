var files_dup =
[
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "myexception.cpp", "myexception_8cpp.html", null ],
    [ "myexception.hpp", "myexception_8hpp.html", [
      [ "myexception", "classmyexception.html", "classmyexception" ]
    ] ],
    [ "Song.cpp", "_song_8cpp.html", null ],
    [ "Song.h", "_song_8h.html", "_song_8h" ],
    [ "Songs.cpp", "_songs_8cpp.html", null ],
    [ "Songs.h", "_songs_8h.html", [
      [ "Songs", "class_songs.html", "class_songs" ]
    ] ]
];