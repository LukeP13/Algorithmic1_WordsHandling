var main_8cpp =
[
    [ "deleteId", "main_8cpp.html#a3e141ccc5d02fb279618392149e032a6", null ],
    [ "getId", "main_8cpp.html#a47d259dd8eaf247ba8f0ab688435bb20", null ],
    [ "ignorarComentaris", "main_8cpp.html#a80b5222678194224cb7d46f0ca33bb61", null ],
    [ "llegirMFW", "main_8cpp.html#a88f6df82d3f3f97f80c3d2f93ad49030", null ],
    [ "llegirMSD", "main_8cpp.html#a00c5a4994344cccb03bd69186fd02c2a", null ],
    [ "llegirMXM", "main_8cpp.html#ac98514d551a9f410c9410027115d40ca", null ],
    [ "llegWordSong", "main_8cpp.html#a7dc0fdcf32d93f2810175aeed9b001a3", null ],
    [ "main", "main_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ],
    [ "mostFreqIn", "main_8cpp.html#a19b652082321c94737b051ed6bd042e9", null ],
    [ "mostFreqN", "main_8cpp.html#a2d27d4d90c2652a35f52e6679e49f5fd", null ],
    [ "Operacions", "main_8cpp.html#aeb00393230810abb86495afef8a1c5d5", null ],
    [ "tractarOp", "main_8cpp.html#a0081290c0d81a2119bca5ae4c0ff2426", null ],
    [ "whereWord", "main_8cpp.html#a44e58a833554abcb447b925f689210f6", null ]
];