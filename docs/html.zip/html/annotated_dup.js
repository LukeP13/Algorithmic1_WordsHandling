var annotated_dup =
[
    [ "myexception", "classmyexception.html", "classmyexception" ],
    [ "Song", "class_song.html", "class_song" ],
    [ "Songs", "class_songs.html", "class_songs" ]
];