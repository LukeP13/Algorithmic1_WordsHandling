var classmyexception =
[
    [ "myexception", "classmyexception.html#adb0260a0cb826755f83ca9ea545fbcac", null ],
    [ "~myexception", "classmyexception.html#a424f99b09d97a1a3c202f0fd95edee4d", null ],
    [ "what", "classmyexception.html#a5f732c127a10f2fd5820e1e19a8c562f", null ]
];