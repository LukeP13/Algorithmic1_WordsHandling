var class_songs =
[
    [ "Songs", "class_songs.html#a83af5e2d45ba37bc6060f72cd838b8a8", null ],
    [ "addSong", "class_songs.html#a6799ddad7af7b27b366b6b43b343dae3", null ],
    [ "addWord", "class_songs.html#a7883193508bde2f67d2b87b062964bc7", null ],
    [ "deleteSong", "class_songs.html#ab4e301c515d165edfc78ee79b965558f", null ],
    [ "existeix", "class_songs.html#ad2618d1aef7ac84c9b44a76eb18be3c7", null ],
    [ "getSong", "class_songs.html#a01879ad0a21ed5ddb18ea8807a998201", null ],
    [ "mostFrequentN", "class_songs.html#a835a6d470f21eac62d66a2444b1f2df6", null ],
    [ "mostFrequentWordsIn", "class_songs.html#aeab3dc2a5a8bee6a6a1f17a4942640c9", null ],
    [ "songsWithWord", "class_songs.html#a8ac22afd669418f093800e84bdc62ba7", null ]
];