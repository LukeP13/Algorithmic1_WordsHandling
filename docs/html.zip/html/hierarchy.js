var hierarchy =
[
    [ "exception", null, [
      [ "myexception", "classmyexception.html", null ]
    ] ],
    [ "Song", "class_song.html", null ],
    [ "Songs", "class_songs.html", null ]
];