var class_song =
[
    [ "Song", "class_song.html#a1a73ff262627ce78860ec622859cf249", null ],
    [ "Song", "class_song.html#a4c196c63edcfdae5d314fa6ff8eb4b66", null ],
    [ "~Song", "class_song.html#a0749c3367e8de89e27458c248377027b", null ],
    [ "addWord", "class_song.html#acd87e76192df5408435cc4dfeb785397", null ],
    [ "count", "class_song.html#ae4ce397c89bd6d5a794b5ebebf3fc9c7", null ],
    [ "getInfo", "class_song.html#aee7b19626c5cea2322e050afb124f1c9", null ],
    [ "haveWord", "class_song.html#a41506ac527f8c62b25149e36738eb4d8", null ],
    [ "mostFrequentWordIdxs", "class_song.html#ad916f0c638cfa4f6673efafe632a6858", null ],
    [ "mXm_artist_name", "class_song.html#af86e2beb193959ec1ae8f602eb77efa7", null ],
    [ "mXm_tid", "class_song.html#a8bf39a68be9d65d90c6bda27a3a444bc", null ],
    [ "mXm_title", "class_song.html#af869a809a8f909ab874280399ebb5d75", null ],
    [ "paraules", "class_song.html#a8e70c20ee5d776e6d174240995b067d7", null ],
    [ "tid", "class_song.html#a5c888b5f5afff211fb0c4818f99f3ddb", null ]
];